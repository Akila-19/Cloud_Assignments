<?php
// Replace these with your database connection details
$servername = "localhost";
$username = "akilaAdminCM";
$password = "akilavasan";
$dbname = "customer_management_db";


// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update'])) {
    // Handle the form submission to update the customer details here
    $customerID = $_POST['id'];
    $newFirstName = $_POST['new_first_name'];
    $newLastName = $_POST['new_last_name'];
    $newEmail = $_POST['new_email'];
    $newPhoneNumber = $_POST['new_phone_number'];
    $newNotes = $_POST['new_notes'];

    // Use prepared statements to update the record
    $sql = "UPDATE customer_details SET first_name=?, last_name=?, email=?, phone=?, notes=? WHERE id=?";
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bind_param("sssssi", $newFirstName, $newLastName, $newEmail, $newPhoneNumber, $newNotes, $customerID);

    if ($stmt->execute()) {
        // Update successful
        header("Location: editContact.php");
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
}
if (isset($_GET['delete'])) {
    // Handle customer deletion based on ID passed in the URL
    $customerID = $_GET['delete'];

    // Display a confirmation dialog before deleting
    if (isset($_GET['confirm'])) {
        // Delete the customer record based on confirmation
        if ($_GET['confirm'] === 'yes') {
            $sql = "DELETE FROM customer_details WHERE id = $customerID";
            if ($conn->query($sql) === TRUE) {
                // Deletion successful
                header("Location: editContact.php");
            } else {
                echo "Error deleting record: " . $conn->error;
            }
        } else {
            // User canceled deletion, redirect to the previous page
            header("Location: editContact.php");
        }
    } else {
        // Prompt the user for confirmation
        echo "<script>
                if (confirm('Are you sure you want to delete this customer?')) {
                    window.location.href = 'editContact.php?delete=$customerID&confirm=yes';
                } else {
                    window.location.href = 'editContact.php';
                }
              </script>";
    }
}
if (isset($_GET['edit'])) {
    // Fetch the customer details based on the ID from the URL
    $customerID = $_GET['edit'];
    $sql = "SELECT * FROM customer_details WHERE id = $customerID";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Customer Details</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5 border border-4" style="background-color: pink;height: 625px!important;">
        <h2>Edit Customer Details</h2>
        <form method="post">
            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
            <div class="form-group">
                <label for="new_first_name">First Name</label>
                <input type="text" class="form-control" name="new_first_name" value="<?php echo $row['first_name']; ?>">
            </div>
            <div class="form-group">
                <label for="new_last_name">Last Name</label>
                <input type="text" class="form-control" name="new_last_name" value="<?php echo $row['last_name']; ?>">
            </div>
            <div class="form-group">
                <label for="new_email">Email</label>
                <input type="text" class="form-control" name="new_email" value="<?php echo $row['email']; ?>">
            </div>
            <div class="form-group">
                <label for="new_phone_number">Phone Number</label>
                <input type="text" class="form-control" name="new_phone_number" value="<?php echo $row['phone']; ?>">
            </div>
            <div class="form-group">
                <label for="new_notes">Notes</label>
                <input type="text" class="form-control" name="new_notes" value="<?php echo $row['notes']; ?>">
            </div>
            <button type="submit" name="update" class="btn btn-primary">Update</button>
        </form>
    </div>
    <!-- Include Bootstrap JS (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
    } else {
        echo "Customer not found";
    }
} else {
    // Display customer details in Bootstrap cards
    $sql = "SELECT * FROM customer_details";
    $result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Display and Edit Data in Bootstrap Cards</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<a class="active" href="homePage.html">Back to Home Page</a>
    <div class="container">
        <h2>Customer Details</h2>
        <div class="row">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<div class="col-md-4">';
                    echo '<div class="card my-3">';
                    echo '<div class="card-body" style="background-color:lightpink">';
                    echo '<h5 class="card-title">' . $row["first_name"] . ' ' . $row["last_name"] . '</h5>';
                    echo '<h6 class="card-subtitle mb-2 text-muted">' . $row["email"] . '</h6>';
                    echo '<p class="card-text">Phone: ' . $row["phone"] . '</p>';
                    echo '<p class="card-text">Notes: ' . $row["notes"] . '</p>';
                    echo '<a href="?edit=' . $row["id"] . '" class="btn btn-primary mr-3">Edit</a>';
                    echo '<a href="?delete=' . $row["id"] . '" class="btn btn-primary">Delete</a>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
            } else {
                echo "0 results";
            }
            ?>
        </div>
    </div>
    <!-- Include Bootstrap JS (optional) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
<?php
}

// Close the database connection
$conn->close();
?>
