<!DOCTYPE html>
<html style="
    height: 100%;
    background-color: aquamarine;
">

<head>
	<title>Insert Page page</title>
</head>

<body style="
    margin-left: 550px;
    margin-top: 120px;
    border: 1px solid;
    padding: 20px;
    width: 461px;
    background-color: white;
">
	<centre  >
		<?php

		// servername => localhost now rds endpoint
		// username => root now your db username 
		// password => empty now your open password
		// database name => Your database name
		$conn = mysqli_connect("localhost", "akilaAdminCM", "akilavasan", "customer_management_db");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		// Taking all 5 values from the form data(input)
		$first_name = $_REQUEST['first_name'];
		$last_name = $_REQUEST['last_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phoneNumber'];
		$notes = $_REQUEST['notes'];
		
		// Performing insert query execution
		// here our table name is college
		$sql = "INSERT INTO customer_details(first_name,
		last_name,email,phone,notes) VALUES ('$first_name',
			'$last_name','$email','$phone', '$notes')";
		
		if(mysqli_query($conn, $sql)){
			// echo `<h3 class="text-centre">Data stored in a Database Successfully!!!! Thanks for the Registration"
			// 	"</h3>"`;
			echo '<h3 class="text-center">Data stored in a Database Successfully!!!! Thanks for the Registration</h3>';


			echo nl2br("\n$first_name\n $last_name\n "
				. "$email\n $phone\n $notes");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		// Close connection
		mysqli_close($conn);
		?>
	</centre>
</body>

</html>




